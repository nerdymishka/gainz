using System;

namespace Tests
{

    public interface IFakeService { }


    public interface IFakeServiceInstance : IFakeService
    {
    }

    public interface IFakeSingletonService : IFakeService
    {
    }

    public interface IFakeScopedService : IFakeService
    {
    }

    public interface IFakeEveryService :
            IFakeScopedService,
            IFakeServiceInstance,
            IFakeSingletonService
    {
    }

    public interface INonexistentService
    {
    }

    public class FakeService : IFakeEveryService, IDisposable
    {
        public bool Disposed { get; private set; }

        public void Dispose()
        {
            Disposed = true;
        }
    }
}