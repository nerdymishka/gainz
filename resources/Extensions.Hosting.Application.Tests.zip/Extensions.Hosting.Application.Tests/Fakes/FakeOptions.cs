namespace Tests
{
    public class FakeOptions
    {
        public bool Configured { get; set; }
        public string Environment { get; set; }
        public string Message { get; set; }
    }
}