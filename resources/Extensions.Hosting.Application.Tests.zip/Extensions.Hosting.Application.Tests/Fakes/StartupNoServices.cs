using NerdyMishka.Extensions.Hosting;

namespace Tests
{
    public class StartupNoServices : StartupBase
    {
        public StartupNoServices()
        {
        }

        public override void Configure(IApplicationBuilder builder)
        {
        }
    }
}