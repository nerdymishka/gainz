using System;
using NerdyMishka.Extensions.Hosting;

namespace Tests 
{

    public class StartupCtorThrows
    {
        public StartupCtorThrows()
        {
            throw new Exception("Exception from constructor");
        }

        public void Configure(IApplicationBuilder app)
        {
        }
    }
}