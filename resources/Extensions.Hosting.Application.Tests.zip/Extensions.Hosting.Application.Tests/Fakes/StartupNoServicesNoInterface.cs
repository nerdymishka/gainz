using Microsoft.Extensions.DependencyInjection;
using NerdyMishka.Extensions.Hosting;

namespace Tests{
    public class StartupNoServicesNoInterface
    {
        public void ConfigureServices(IServiceCollection services)
        {

        }

        public void Configure(IApplicationBuilder app)
        {
            
        }
    }
}