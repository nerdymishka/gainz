using Microsoft.Extensions.Hosting;
using NerdyMishka.Extensions.Hosting;

namespace Tests
{
    public class StartupWithHostingEnvironment
    {
        public StartupWithHostingEnvironment(IHostEnvironment env)
        {
            env.EnvironmentName = "Changed";
        }

        public void Configure(IApplicationBuilder app)
        {

        }
    }
}