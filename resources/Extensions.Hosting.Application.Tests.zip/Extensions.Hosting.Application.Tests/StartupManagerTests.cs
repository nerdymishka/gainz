

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using NerdyMishka.Extensions.Hosting;
using Xunit;

namespace Tests 
{
    public class StartupManagerTests
    {
        [Fact]
        public void ConventionalStartupClass_StartupServiceFilters_WrapsConfigureServicesMethod()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddSingleton<IServiceProviderFactory<IServiceCollection>, DefaultServiceProviderFactory>();

            var services = serviceCollection.BuildServiceProvider();

            var type = typeof(VoidReturningStartupServicesFiltersStartup);
            var startup = StartupLoader.LoadMethods(services, type, "");

            var applicationServices = startup.ConfigureServicesDelegate(serviceCollection);
            var before = applicationServices.GetRequiredService<ServiceBefore>();
            var after = applicationServices.GetRequiredService<ServiceAfter>();

            Assert.Equal("StartupServicesFilter Before 1", before.Message);
            Assert.Equal("StartupServicesFilter After 1", after.Message);
        }
    }


    public class VoidReturningStartupServicesFiltersStartup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services.TryAddSingleton(new ServiceBefore { Message = "Configure services" });
            services.TryAddSingleton(new ServiceAfter { Message = "Configure services" });
        }

        public void Configure(IApplicationBuilder builder)
        {
        }
    }

    public class ServiceBefore
    {
        public string Message { get; set; }
    }

    public class ServiceAfter
    {
        public string Message { get; set; }
    }
}