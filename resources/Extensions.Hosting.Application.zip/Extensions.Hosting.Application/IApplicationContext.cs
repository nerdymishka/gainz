


using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using Microsoft.Extensions.Configuration;

namespace NerdyMishka.Extensions.Hosting
{

    public interface IApplicationContext
    {
        IConfiguration Configuration { get; }

        IServiceProvider Services { get; }

        object this[string key] { get; set; }

        int ExitCode { get; set; }

        System.Security.Principal.IPrincipal User { get; set; }
    }

    public class ApplicationContext : IApplicationContext
    {
        private ConcurrentDictionary<string, object> lookup = new ConcurrentDictionary<string, object>();
        public ApplicationContext()
        {

        }

        public IConfiguration Configuration { get; set;}

        public IServiceProvider Services { get; set; }

        public object this[string key] 
        {
            get {
                object value = null;
                this.lookup.TryGetValue(key, out value);
           

                return value;
            }
            set{  this.lookup.AddOrUpdate(key, value, (k, v) => value); }
        }

        public int ExitCode { get; set; }

        public System.Security.Principal.IPrincipal User { get; set; }
    
    }
}