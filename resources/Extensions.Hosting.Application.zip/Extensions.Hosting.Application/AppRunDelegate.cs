


using System.Threading.Tasks;

namespace NerdyMishka.Extensions.Hosting
{

    public delegate Task AppRunDelegate(IApplicationContext context);
}