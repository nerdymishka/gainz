

using System;
using System.Collections.Generic;

namespace NerdyMishka.Extensions.Hosting
{
    public interface IApplicationBuilder 
    {
        IServiceProvider ApplicationServices { get; set; }

        IDictionary<string, object> Properties { get; set; }

        IApplicationBuilder Use(Func<AppRunDelegate, AppRunDelegate> middleware);

        IApplicationBuilder Create();

        AppRunDelegate Build();
    }
}