
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Microsoft.Extensions.Configuration;

namespace NerdyMishka.Extensions.Hosting
{
    public class ApplicationHostOptions
    {

        public ApplicationHostOptions(IConfiguration configuration, string applicationNameFallback)
        {
            if (configuration == null)
            {
                throw new ArgumentNullException(nameof(configuration));
            }

            ApplicationName = configuration["applicationName"] ?? applicationNameFallback;
            StartupAssembly = configuration["startupAssembly"];
            DetailedErrors = ParseBool(configuration, "detailedErrors");
            CaptureStartupErrors = ParseBool(configuration, "captureStartupErrors");
            Environment = configuration["environment"];

            PreventHostingStartup = ParseBool(configuration, "preventHostingStartup");
            SuppressStatusMessages = ParseBool(configuration, "suppressStatusMessages");

            // Search the primary assembly and configured assemblies.
            HostingStartupAssemblies = Split($"{ApplicationName};{configuration["hostingStartupAssemblies"]}");
            HostingStartupExcludeAssemblies = Split(configuration["hostingStartupExcludeAssembliesKey"]);

            var timeout = configuration["shutdownTimeoutSeconds"];
            if (!string.IsNullOrEmpty(timeout)
                && int.TryParse(timeout, NumberStyles.None, CultureInfo.InvariantCulture, out var seconds))
            {
                ShutdownTimeout = TimeSpan.FromSeconds(seconds);
            }
        }

        private static bool ParseBool(IConfiguration configuration, string key)
        {
            var value = configuration["detailedErrors"];
            if(value != null)
                return value.ToLowerInvariant() == "true" ? true : false;

            return false;
        }

        public string ApplicationName { get; set; }

        public bool PreventHostingStartup { get; set; }

        public bool SuppressStatusMessages { get; set; }

        public IReadOnlyList<string> HostingStartupAssemblies { get; set; }

        public IReadOnlyList<string> HostingStartupExcludeAssemblies { get; set; }

        public bool DetailedErrors { get; set; }

        public bool CaptureStartupErrors { get; set; }

        public string Environment { get; set; }

        public string StartupAssembly { get; set; }

        public TimeSpan ShutdownTimeout { get; set; } = TimeSpan.FromSeconds(5);

        public IEnumerable<string> GetFinalHostingStartupAssemblies()
        {
            return HostingStartupAssemblies.Except(HostingStartupExcludeAssemblies, StringComparer.OrdinalIgnoreCase);
        }

        private IReadOnlyList<string> Split(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return Array.Empty<string>();
            }

            var list = new List<string>();
            foreach (var part in value.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var trimmedPart = part;
                if (!string.IsNullOrEmpty(trimmedPart))
                {
                    list.Add(trimmedPart);
                }
            }
            return list;
        }
    }


      
}