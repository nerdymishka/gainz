
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace NerdyMishka.Extensions.Hosting
{
    public class HostedServiceExecutor
    {
        private readonly IEnumerable<IHostedService> services;
        private readonly ILogger<HostedServiceExecutor> logger;

        public HostedServiceExecutor(ILogger<HostedServiceExecutor> logger, IEnumerable<IHostedService> services)
        {
            this.logger = logger;
            this.services = services;
        }

        public async Task StartAsync(CancellationToken token)
        {
            try
            {
                await ExecuteAsync(service => service.StartAsync(token));
            }
            catch (Exception ex)
            {
                logger.ApplicationError(LoggerEventIds.HostedServiceStartException, "An error occurred starting the application", ex);
            }
        }

        public async Task StopAsync(CancellationToken token)
        {
            try
            {
                await ExecuteAsync(service => service.StopAsync(token));
            }
            catch (Exception ex)
            {
                logger.ApplicationError(LoggerEventIds.HostedServiceStopException, "An error occurred stopping the application", ex);
            }
        }

        private async Task ExecuteAsync(Func<IHostedService, Task> callback)
        {
            List<Exception> exceptions = null;

            foreach (var service in services)
            {
                try
                {
                    await callback(service);
                }
                catch (Exception ex)
                {
                    if (exceptions == null)
                    {
                        exceptions = new List<Exception>();
                    }

                    exceptions.Add(ex);
                }
            }

            // Throw an aggregate exception if there were any exceptions
            if (exceptions != null)
            {
                throw new AggregateException(exceptions);
            }
        }
    }
}

 