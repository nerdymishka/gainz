# Application Host Prototype

Port of ASP.NET Hosting extensions for other dotnet applications.  

https://github.com/aspnet/AspNetCore/tree/master/src/Hosting/Hosting