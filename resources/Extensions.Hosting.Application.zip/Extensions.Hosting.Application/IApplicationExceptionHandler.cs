

using System;
using System.Threading;
using System.Threading.Tasks;
using NerdyMishka.Extensions.Hosting;

namespace NerdyMisha.Extensions.Hosting
{
    public interface IApplicationExceptionHandler
    {
        Task ExecuteAsync(IApplicationContext context, CancellationToken token = default);
    }

    public class DefaultApplicationExceptionHandler : IApplicationExceptionHandler
    {
        public Task ExecuteAsync(IApplicationContext context, CancellationToken token = default)
        {
            return new Task(() => {
                var exception = context["LastException"] as Exception;
                if(exception != null)
                {
                    Console.Error.WriteLine(exception);
                }
            });
        }
    }
}