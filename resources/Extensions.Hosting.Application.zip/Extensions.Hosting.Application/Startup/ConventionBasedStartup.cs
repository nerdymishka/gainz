using System;
using System.Reflection;
using System.Runtime.ExceptionServices;
using Microsoft.Extensions.DependencyInjection;
using NerdyMishka.Extensions.Hosting;

internal class ConventionBasedStartup : IStartup
{
    private readonly StartupMethods methods;

    public ConventionBasedStartup(StartupMethods methods)
    {
        this.methods = methods;
    }
    
    public void Configure(IApplicationBuilder app)
    {
        try
        {
            this.methods.ConfigureDelegate(app);
        }
        catch (Exception ex)
        {
            if (ex is TargetInvocationException)
            {
                ExceptionDispatchInfo.Capture(ex.InnerException).Throw();
            }

            throw;
        }
    }

    public IServiceProvider ConfigureServices(IServiceCollection services)
    {
        try
        {
            return this.methods.ConfigureServicesDelegate(services);
        }
        catch (Exception ex)
        {
            if (ex is TargetInvocationException)
            {
                ExceptionDispatchInfo.Capture(ex.InnerException).Throw();
            }

            throw;
        }
    }
}