
using System;
using Microsoft.Extensions.DependencyInjection;

namespace NerdyMishka.Extensions.Hosting
{
    public class DelegateStartup : StartupBase<IServiceCollection>
    {
        private Action<IApplicationBuilder> configureApp;

        public DelegateStartup(IServiceProviderFactory<IServiceCollection> factory, Action<IApplicationBuilder> configureApp) : base(factory)
        {
            this.configureApp = configureApp;
        }

        public override void Configure(IApplicationBuilder app) => this.configureApp(app);
    }
}