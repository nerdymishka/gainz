

using System;
using Microsoft.Extensions.DependencyInjection;

namespace NerdyMishka.Extensions.Hosting
{
    // modeled after: https://github.com/aspnet/AspNetCore/blob/master/src/Hosting/Hosting/src/Startup/StartupBase.cs
    /// <summary>
    /// 
    /// </summary>
    public abstract class StartupBase : IStartup
    {
        public abstract void Configure(IApplicationBuilder app);

        public virtual void ConfigureServices(IServiceCollection services)
        {

        }

        public virtual IServiceProvider CreateServiceProvider(IServiceCollection services)
        {
            return services.BuildServiceProvider();
        }

        IServiceProvider IStartup.ConfigureServices(IServiceCollection services)
        {
            this.ConfigureServices(services);
            return this.CreateServiceProvider(services);
        }
    }

    public abstract class StartupBase<TBuilder> : StartupBase
    {
        private IServiceProviderFactory<TBuilder> factory;

        public StartupBase(IServiceProviderFactory<TBuilder> factory) 
            => this.factory = factory;

        public override IServiceProvider CreateServiceProvider(IServiceCollection services)
        {
            var builder = this.factory.CreateBuilder(services);
            this.ConfigureContainer(builder);
            return this.factory.CreateServiceProvider(builder);
        }

        public virtual void ConfigureContainer(TBuilder builder)
            => this.factory.CreateServiceProvider(builder);
    }
}