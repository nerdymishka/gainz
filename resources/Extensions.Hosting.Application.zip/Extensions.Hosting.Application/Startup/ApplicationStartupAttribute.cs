using System;
using System.Reflection;

namespace NerdyMishka.Extensions.Hosting
{
    [AttributeUsage(AttributeTargets.Assembly, Inherited = false, AllowMultiple = true)]
    public sealed class ApplicationStartupAttribute : Attribute
    {
        /// <summary>
        /// Constructs the <see cref="applicationStartupAttribute"/> with the specified type.
        /// </summary>
        /// <param name="applicationStartupType">A type that implements <see cref="IapplicationStartup"/>.</param>
        public ApplicationStartupAttribute(Type applicationStartupType)
        {
            if (applicationStartupType == null)
            {
                throw new ArgumentNullException(nameof(applicationStartupType));
            }

            if (!typeof(IApplicationStartup)
                .GetTypeInfo()
                .IsAssignableFrom(applicationStartupType.GetTypeInfo()))
            {
                throw new ArgumentException($@"""{applicationStartupType}"" does not implement {typeof(IApplicationStartup)}.", nameof(applicationStartupType));
            }

            ApplicationStartupType = applicationStartupType;
        }

        /// <summary>
        /// The implementation of <see cref="IapplicationStartup"/> that should be loaded when 
        /// starting an application.
        /// </summary>
        public Type ApplicationStartupType { get; }
    }
}