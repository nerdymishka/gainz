

namespace NerdyMishka.Extensions.Hosting
{
    public interface IApplicationStartup
    {
        
        void Configure(IApplicationHostBuilder builder);
    }
}