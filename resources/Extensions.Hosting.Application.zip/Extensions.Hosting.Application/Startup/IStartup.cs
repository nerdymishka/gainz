

using System;
using Microsoft.Extensions.DependencyInjection;

namespace NerdyMishka.Extensions.Hosting
{
    public interface IStartup
    {
        IServiceProvider ConfigureServices(IServiceCollection services);

        void Configure(IApplicationBuilder app);
    }
}