

using System;

namespace NerdyMishka.Extensions.Hosting
{

    internal interface ISupportsStartup
    {
        IApplicationHostBuilder Configure(Action<ApplicationHostBuilderContext, IApplicationBuilder> configure);
        IApplicationHostBuilder UseStartup(Type startupType);
    }
}
