using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;

namespace NerdyMishka.Extensions.Hosting
{
    internal class ApplicationHostEnvironment : IHostEnvironment
    {
        public string EnvironmentName { get; set; } = Microsoft.Extensions.Hosting.Environments.Production;

        public string ApplicationName { get; set; }

        public string WebRootPath { get; set; }

        public IFileProvider WebRootFileProvider { get; set; }

        public string ContentRootPath { get; set; }

        public IFileProvider ContentRootFileProvider { get; set; }

    }
}