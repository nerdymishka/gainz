

using System;
using System.Reflection;
using Microsoft.Extensions.Logging;

internal static class LoggerEventIds
{
    public const int RequestStarting = 1;
    public const int RequestFinished = 2;
    public const int Starting = 3;
    public const int Started = 4;
    public const int Shutdown = 5;
    public const int ApplicationStartupException = 6;
    public const int ApplicationStoppingException = 7;
    public const int ApplicationStoppedException = 8;
    public const int HostedServiceStartException = 9;
    public const int HostedServiceStopException = 10;
    public const int HostingStartupAssemblyException = 11;
    public const int ServerShutdownException = 12;
}

internal static class HostingLoggerExtensions
{

    public static void ApplicationError(this ILogger logger, Exception exception)
    {
        logger.ApplicationError(
            eventId: LoggerEventIds.ApplicationStartupException,
            message: "Application startup exception",
            exception: exception);
    }


    public static void ApplicationError(this ILogger logger, EventId eventId, string message, Exception exception)
    {
        var reflectionTypeLoadException = exception as ReflectionTypeLoadException;
        if (reflectionTypeLoadException != null)
        {
            foreach (var ex in reflectionTypeLoadException.LoaderExceptions)
            {
                message = message + Environment.NewLine + ex.Message;
            }
        }

        logger.LogCritical(
            eventId: eventId,
            message: message,
            exception: exception);
    }

    public static void Starting(this ILogger logger)
    {
        if (logger.IsEnabled(LogLevel.Debug))
        {
            logger.LogDebug(
               eventId: LoggerEventIds.Starting,
               message: "Hosting starting");
        }
    }

    public static void Started(this ILogger logger)
    {
        if (logger.IsEnabled(LogLevel.Debug))
        {
            logger.LogDebug(
                eventId: LoggerEventIds.Started,
                message: "Hosting started");
        }
    }

    public static void Shutdown(this ILogger logger)
    {
        if (logger.IsEnabled(LogLevel.Debug))
        {
            logger.LogDebug(
                eventId: LoggerEventIds.Shutdown,
                message: "Hosting shutdown");
        }
    }

    public static void ServerShutdownException(this ILogger logger, Exception ex)
    {
        if (logger.IsEnabled(LogLevel.Debug))
        {
            logger.LogDebug(
                eventId: LoggerEventIds.ServerShutdownException,
                exception: ex,
                message: "Server shutdown exception");
        }
    }
}