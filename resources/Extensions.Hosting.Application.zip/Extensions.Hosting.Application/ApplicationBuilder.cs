

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NerdyMishka.Extensions.Hosting
{
    public class ApplicationBuilder : IApplicationBuilder
    {
        internal const string ServerFeaturesKey = "server.Features";
        internal const string ApplicationServicesKey = "application.Services";

        private IServiceProvider serviceProvider;

        private readonly IList<Func<AppRunDelegate, AppRunDelegate>> components = 
            new List<Func<AppRunDelegate, AppRunDelegate>>();


        public ApplicationBuilder(IServiceProvider serviceProvider)
        {
            this.Properties = new Dictionary<string, object>(StringComparer.Ordinal);
            this.serviceProvider = serviceProvider;
            
        }

        private ApplicationBuilder(ApplicationBuilder parent)
        {
            Properties = new CopyOnWriteDictionary<string, object>(parent.Properties, StringComparer.Ordinal);
        }


        public IServiceProvider ApplicationServices { get; set; }
        public IDictionary<string, object> Properties { get; set; }

        public IApplicationBuilder Use(Func<AppRunDelegate, AppRunDelegate> middleware)
        {
            this.components.Add(middleware);
            return this;
        }

        public IApplicationBuilder Create()
        {
            return new ApplicationBuilder(this);
        }

        public AppRunDelegate Build()
        {
            AppRunDelegate app = (context) => {
                context.ExitCode = 1;

                return Task.CompletedTask;
            };

            foreach (var component in this.components.Reverse())
            {
                app = component(app);
            }

            return app;
        }
    }
}