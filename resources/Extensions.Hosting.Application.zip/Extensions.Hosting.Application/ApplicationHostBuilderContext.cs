

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;

namespace NerdyMishka.Extensions.Hosting
{
    public class ApplicationHostBuilderContext
    {
        public IHostEnvironment HostEnvironment { get; set; }

        public IConfiguration Configuration { get; set; }
    }
}