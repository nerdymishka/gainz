


using System;
using System.Threading;
using System.Threading.Tasks;

namespace NerdyMishka.Extensions.Hosting
{
    public interface IApplicationHost : IDisposable
    {

        IServiceProvider ServiceProvider { get; }

        void Start();

        Task StartAsync(CancellationToken cancellationToken = default);

        Task StopAsync(CancellationToken cancellationToken = default);
    }
}