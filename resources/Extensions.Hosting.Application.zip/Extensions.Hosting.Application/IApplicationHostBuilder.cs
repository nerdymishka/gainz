

using System;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace NerdyMishka.Extensions.Hosting
{
    public interface IApplicationHostBuilder
    {
        IApplicationHostBuilder ConfigureAppConfiguration(
            Action<ApplicationHostBuilderContext, IConfigurationBuilder> configure);

        IApplicationHostBuilder ConfigureServices(
            Action<IServiceCollection> configureServices);


        IApplicationHostBuilder ConfigureServices(
            Action<ApplicationHostBuilderContext, IServiceCollection> configure);

        IApplicationHost Build();

        IApplicationHostBuilder UseSetting(string key, string value);

        string GetSetting(string key);
    }
}