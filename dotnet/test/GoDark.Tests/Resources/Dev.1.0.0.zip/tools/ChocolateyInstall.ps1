

Import-Module "$PSScriptRoot\update.psm1" -Force 

Write-Debug "Check!"
if(!(Test-Checkpoint "MiniInstall"))
{
    Write-Debug "MiniInstall"
    Install-ChocolateyPkg "keepass"
    Install-ChocolateyPkg "openvpn"
    Install-ChocolateyPkg "vscode"
    Install-ChocolateyPkg "docfx"
    
    Install-ChocolateyPkg "googlechrome"
    Install-ChocolateyPkg "git-credential-manager-for-windows"
    Install-ChocolateyPkg "nodejs-lts"
    choco pin add -n="nodejs-lts"
    Install-ChocolateyPkg "adobereader"
    Install-ChocolateyPkg "7zip"
    Install-ChocolateyPkg "adobereader"
    Install-ChocolateyPkg "dotnetcore-sdk"
    Install-ChocolateyPkg "sql-server-management-studio"
    Install-ChocolateyPkg "docker-for-windows"

    Save-Checkpoint "MiniInstall"
}





if (Test-PendingReboot) { Invoke-Reboot }

if(!(Test-Checkpoint "VisualStudio"))
{
    $parameters = "--params=`"'--in $PSScriptRoot/visualstudio-pro-2017.json'`""

    Install-ChocolateyPkg "visualstudio2017professional" -ArgumentList $parameters
    choco pin add -n="visualstudio2017professional"
    Save-Checkpoint "VisualStudio"

    if (Test-PendingReboot) { Invoke-Reboot }
}



if(!(Test-Checkpoint "SqlServer"))
{
    $pw = New-Password -Length 20 -AsString 
    $c = Get-Content "$PSScriptRoot\sqlserver-2017.ini"
    $c.Replace("{{ sa }}", $pw)
    $c | Set-Content "$PSScriptRoot\sqlserver-2017.ini" -Value $c

    $parameters = "--params=`"' /ConfigurationFile:`"$PSScriptRoot\sqlserver-2017.ini`"'`""
    
    Install-ChocolateyPkg "sql-server-2017" -ArgumentList $parameters
    choco pin add -n="sql-server-2017"
    Save-Checkpoint "SqlServer"

    if (Test-PendingReboot) { Invoke-Reboot }
}

if(!(Test-Checkpoint "WindowsFeatures"))
{
    Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Windows-Subsystem-Linux -All -NoRestart 

    Save-Checkpoint "WindowsFeatures"
    if (Test-PendingReboot) { Invoke-Reboot }
}


Install-WindowsUpdate -all 
if (Test-PendingReboot) { Invoke-Reboot }


choco update all -y


Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Windows-Subsystem-Linux
#Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V -All

